import React from "react";

 function Info(){
   return(
     <div className="note">
       <h1>Javascript and React.js</h1>
       <p>This was an amazing Bootcamp taken up by Shaurya Sinha We covered Everything From Scratch including Javascript,React.js,HTML</p>
       </div>
   );
 }
 export default Info;